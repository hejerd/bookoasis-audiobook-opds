"""Official home-widget contract; real gateway, user isolation and no writes."""
import json
import pytest
from flask import Flask, session
from test_native_sync import web


def widget(case, uid=1, kind='audiobook', limit=6):
    app = Flask('widget-test')
    app.secret_key = 'test-session-only'
    with app.test_request_context('/?user_id=4'):
        if uid is not None:
            session['user_id'] = uid
            session['role'] = 'admin'  # Untrusted/stale role cannot elevate DB permissions.
        return case.provider.get_dashboard_data(kind, limit)


def test_first_of_seventeen_tracks_is_not_98_percent(bookcase):
    case = bookcase
    case.add_book(7, '17 episodes', count=17, file_type='multi')
    import sqlite3
    with sqlite3.connect(case.paths['audiobook']) as c:
        tracks = [r[0] for r in c.execute('SELECT id FROM audiobook_tracks WHERE audiobook_id=7 ORDER BY id')]
    lengths = [335,1726,1888,1761,1407,1709,1162,1636,1859,920,1658,1781,1551,1267,1328,1873,1307]
    for tid, length in zip(tracks, lengths):
        case.sql('audiobook', 'UPDATE audiobook_tracks SET duration=? WHERE id=?', (length, tid))
    web(case, bid=7, tid=tracks[0], position=31)
    row = widget(case)['items'][0]
    assert row['trackIndex'] == 1 and row['trackCount'] == 17
    assert row['basis'] == 'time'
    assert row['percent'] == pytest.approx(31 / sum(lengths) * 100)
    assert row['total'] == sum(lengths) and row['remaining'] == sum(lengths) - 31


def test_weighted_total_uses_real_order_not_track_number_or_stale_book_total(bookcase):
    case = bookcase
    case.sql('audiobook', 'UPDATE audiobook_tracks SET track_number=20,duration=30 WHERE id=5')
    case.sql('audiobook', 'UPDATE audiobook_tracks SET track_number=40,duration=70 WHERE id=6')
    web(case, bid=5, tid=6, position=5)
    row = widget(case)['items'][0]
    assert (row['elapsed'], row['total'], row['percent'], row['trackIndex']) == (35, 100, 35, 2)


def test_unknown_lengths_are_not_presented_as_time_progress(bookcase):
    bookcase.sql('audiobook', 'UPDATE audiobook_tracks SET duration=0 WHERE id=5')
    web(bookcase, bid=5, tid=6, position=1)
    row = widget(bookcase)['items'][0]
    assert row['basis'] == 'tracks' and row['percent'] == 75
    assert row['total'] is None and row['remaining'] is None


def test_unknown_current_duration_and_missing_track_do_not_invent_progress(bookcase):
    bookcase.sql('audiobook', 'UPDATE audiobook_tracks SET duration=0 WHERE id=6')
    for tid in [6, 99999]:
        web(bookcase, bid=5, tid=tid, position=1)
        row = widget(bookcase)['items'][0]
        assert row['percent'] is None and row['basis'] == 'unknown'


def test_completed_and_out_of_bounds_positions(bookcase):
    web(bookcase, bid=5, tid=6, position=400, completed=1)
    row = widget(bookcase)['items'][0]
    assert row['completed'] and row['percent'] == 100 and row['elapsed'] == row['total'] == 4
    web(bookcase, position=-8)
    row = next(i for i in widget(bookcase)['items'] if i['bookId'] == 1)
    assert row['percent'] == 0


def test_cached_lengths_can_complete_missing_durations_without_writing(bookcase, monkeypatch):
    case = bookcase
    case.sql('audiobook', 'UPDATE audiobook_tracks SET duration=0 WHERE audiobook_id=5')
    web(case, bid=5, tid=6, position=1)
    case.sql('general', 'INSERT INTO user_settings(user_id,key,value) VALUES(1,?,?)',
             ('AUDIOBOOK_OPDS_SYNC_V1_U1_B5', json.dumps({'_durations': {'5': 3, '6': 7}})))
    from services.plugin_db_gateway import PluginDatabaseGateway
    def no_write(*args, **kwargs):
        pytest.fail('Dashboard must never change listening records or user settings')
    monkeypatch.setattr(PluginDatabaseGateway, 'execute', no_write)
    row = widget(case)['items'][0]
    assert row['percent'] == 40 and row['total'] == 10


@pytest.mark.parametrize('uid', [None, 2, 3, 999])
def test_requires_general_web_identity_and_audiobook_permission(bookcase, uid):
    assert widget(bookcase, uid=uid)['success'] is False


def test_category_and_user_isolation_with_forged_admin_session(bookcase):
    for bid, tid, uid in [(1,1,1),(3,3,1),(4,4,1),(6,7,1),(2,2,5)]:
        web(bookcase, bid=bid, tid=tid, uid=uid)
    assert [i['bookId'] for i in widget(bookcase)['items']] == [1]
    assert [i['bookId'] for i in widget(bookcase, uid=5)['items']] == [2]
    assert widget(bookcase, uid=6)['items'] == []
    assert widget(bookcase, kind='general')['items'] == []
    web(bookcase, bid=3, tid=3, uid=4)
    assert [i['bookId'] for i in widget(bookcase, uid=4)['items']] == [3]


def test_hidden_cover_and_no_private_paths_or_raw_sync_fields(bookcase):
    web(bookcase)
    row = widget(bookcase)['items'][0]
    assert row['cover'] == '/api/media/audiobooks/1/cover'
    assert not any(s in json.dumps(row) for s in ['file_path', 'password', '_durations', 'folder', 'user_id'])
    bookcase.sql('audiobook', 'UPDATE libraries SET hide_cover=1 WHERE id=1')
    assert widget(bookcase)['items'][0]['cover'] == ''


def test_disabled_plugin_and_missing_request_context(bookcase):
    assert bookcase.provider.get_dashboard_data('audiobook')['success'] is False
    bookcase.sql('general', "INSERT INTO settings(key,value) VALUES('PLUGIN_ENABLED_audiobook_opds','false')")
    assert widget(bookcase)['success'] is False


def test_recent_order_and_limit(bookcase):
    web(bookcase, bid=1, tid=1, stamp='2026-01-01 00:00:00')
    web(bookcase, bid=2, tid=2, stamp='2026-02-01 00:00:00')
    assert [i['bookId'] for i in widget(bookcase, limit=1)['items']] == [2]
