"""Self-hosted sync against the actual BookOasis gateway and SQLite schema."""
import json
import uuid

PATH = "/opds/sync/v1"


def post(case, **body):
    return case.client.post(PATH, headers=case.auth(), json=body)


def mutation(kind="progress", **changes):
    body = {"kind": kind, "baseRevision": 0, "mutationId": str(uuid.uuid4())}
    if kind == "progress":
        body.update(bookId=1, progress={"trackId": 1, "position": 1.25,
                                     "duration": 2, "speed": 1.25, "completed": False})
    else:
        body["bookIds"] = [5, 1]
    body.update(changes)
    return body


def test_discovery_and_persistence(bookcase, plugin):
    case = bookcase
    first = case.client.get(PATH, headers=case.auth())
    assert first.status_code == 200, "Authenticated self-hosted sync discovery must be available"
    data = first.get_json()
    assert data["protocol"] == "bookoasis-audiobook-sync/1"
    assert data["queue"]["bookIds"] == []
    assert data["progress"] == {}
    assert len(data["serverId"]) == 36
    app = plugin.create_app(case.provider, {})
    again = app.test_client().get(PATH, headers=case.auth()).get_json()
    assert again["serverId"] == data["serverId"]
    assert b"bookoasis.org/rel/sync" in case.client.get("/opds", headers=case.auth()).data


def test_progress_revision_conflict_retry_and_account_isolation(bookcase):
    case = bookcase
    body = mutation()
    saved = post(case, **body)
    assert saved.status_code == 200
    assert saved.get_json()["record"]["revision"] == 1
    assert post(case, **body).get_json()["record"]["revision"] == 1
    conflict = post(case, **mutation())
    assert conflict.status_code == 409, "An old device must not overwrite newer listening progress"
    assert conflict.get_json()["record"]["progress"]["position"] == 1.25
    assert post(case, **mutation(baseRevision=1)).get_json()["record"]["revision"] == 2
    another = case.client.get(PATH, headers=case.auth("nodownload")).get_json()
    assert another["progress"] == {}
    assert another["accountId"] != case.client.get(PATH, headers=case.auth()).get_json()["accountId"]


def test_queue_returns_playable_authorized_metadata(bookcase):
    case = bookcase
    assert post(case, **mutation("queue")).status_code == 200
    data = case.client.get(PATH, headers=case.auth()).get_json()
    assert data["queue"]["bookIds"] == [5, 1]
    assert [book["id"] for book in data["books"]] == [5, 1]
    assert len(data["books"][0]["tracks"]) == 2
    assert data["books"][0]["tracks"][0]["href"].endswith("/opds/books/5/tracks/5/stream")
    assert "file_path" not in json.dumps(data)
    case.sql("audiobook", "UPDATE user_category_permissions SET has_access=0 WHERE user_id=1")
    filtered = case.client.get(PATH, headers=case.auth()).get_json()
    assert filtered["queue"]["bookIds"] == []
    assert filtered["books"] == []
    assert post(case, **mutation()).status_code == 404


def test_sync_validates_track_ownership_permissions_and_payload(bookcase):
    case = bookcase
    assert case.client.get(PATH).status_code == 401
    assert case.client.get(PATH, headers=case.auth("blocked")).status_code == 403
    for bid in (3, 4, 6, 999):
        assert post(case, **mutation(bookId=bid)).status_code == 404
    assert post(case, **mutation(progress={"trackId": 2, "position": 1, "duration": 2,
                                         "speed": 1, "completed": False})).status_code == 404
    for changes in ({"baseRevision": -1}, {"baseRevision": True}, {"mutationId": "bad"},
                    {"progress": {"trackId": 1, "position": -1, "duration": 2, "speed": 1, "completed": False}},
                    {"progress": {"trackId": 1, "position": 1, "duration": 2, "speed": 8, "completed": False}},
                    {"userId": 4}):
        assert post(case, **mutation(**changes)).status_code == 400
    assert post(case, **mutation("queue", bookIds=[1, 1])).status_code == 400
    assert post(case, **mutation("queue", bookIds=[1, 3])).status_code == 404
    assert case.client.post(PATH, headers=case.auth(), data="{}", content_type="text/plain").status_code == 415

def test_sync_does_not_pollute_global_configuration(bookcase):
    case = bookcase
    assert post(case, **mutation()).status_code == 200
    assert post(case, **mutation("queue")).status_code == 200
    from services.plugin_db_gateway import PluginDatabaseGateway
    gateway = PluginDatabaseGateway("general")
    rows = gateway.fetch_all("SELECT `key` FROM settings WHERE `key` LIKE 'AUDIOBOOK%'")
    assert [row["key"] for row in rows] == ["AUDIOBOOK_OPDS_SYNC_SERVER_V1"], "Listening records must be user settings, not global configuration"
    rows = gateway.fetch_all("SELECT user_id,`key` FROM user_settings")
    assert len(rows) == 2
    assert all(row["user_id"] == 1 for row in rows)
