"""Native web history/resume + private sync, using upstream SQL gateway/schema."""
import json
import sqlite3
import time
import uuid

from test_sync import PATH, mutation, post


def native(case, bid=1, uid=1):
    with sqlite3.connect(case.paths['audiobook']) as c:
        c.row_factory = sqlite3.Row
        row = c.execute('SELECT * FROM audiobook_progress WHERE audiobook_id=? AND user_id=?', (bid, uid)).fetchone()
        return dict(row) if row else None


def web(case, bid=1, tid=1, position=.75, stamp='2026-10-27 01:00:00', uid=1, completed=0):
    case.sql('audiobook', '''INSERT OR REPLACE INTO audiobook_progress
        (audiobook_id,user_id,current_track_id,current_time,total_progress_pct,playback_rate,is_completed,last_listened_at)
        VALUES(?,?,?,?,?,1.5,?,?)''', (bid, uid, tid, position, 0, completed, stamp))


def get(case):
    r = case.client.get(PATH, headers=case.auth())
    assert r.status_code == 200
    return r.json


def test_app_save_is_visible_in_real_web_history_and_resume(bookcase):
    case = bookcase
    assert post(case, **mutation()).status_code == 200
    row = native(case)
    assert row is not None, 'App sync must also write native web listening progress'
    assert (row['current_track_id'], row['current_time'], row['playback_rate']) == (1, 1.25, 1.25)
    from repositories.sqlite.reading_progress_repository import ReadingProgressRepository
    assert [b['id'] for b in ReadingProgressRepository.fetch_reading_history('audiobook', 1, 10, False)] == [1]
    assert native(case, uid=5) is None


def test_multi_track_position_and_only_played_track_updated(bookcase):
    case = bookcase
    p = dict(trackId=6, position=1, duration=2, speed=1, completed=False)
    assert post(case, **mutation(bookId=5, progress=p)).status_code == 200
    row = native(case, 5)
    assert row and row['current_time'] == 1, 'Core current_time is seconds inside this track'
    assert row['total_progress_pct'] == 75
    with sqlite3.connect(case.paths['audiobook']) as c:
        assert c.execute('SELECT track_id,`current_time`,progress_pct FROM audiobook_track_progress').fetchall() == [(6, 1, 50)]


def test_web_change_imports_and_rejects_stale_app_same_second(bookcase):
    case = bookcase
    saved = post(case, **mutation()).json['record']
    row = native(case)
    assert row is not None
    web(case, position=.5, stamp=row['last_listened_at'])
    stale = post(case, **mutation(baseRevision=saved['revision']))
    assert stale.status_code == 409
    assert stale.json['record']['progress']['position'] == .5
    assert native(case)['current_time'] == .5
    imported = get(case)['progress']['1']
    assert imported['revision'] == saved['revision'] + 1
    assert get(case)['progress']['1'] == imported, 'Polling must not create sync loops'
    assert all(not k.startswith('_') for k in imported), 'Internal bridge state is not part of wire protocol'


def test_web_only_book_enters_app_queue_once(bookcase):
    web(bookcase, bid=5, tid=6, position=1)
    doc = get(bookcase)
    assert doc['queue']['bookIds'] == [5]
    assert doc['books'][0]['id'] == 5
    assert doc['progress']['5']['progress']['trackId'] == 6
    body = mutation('queue', baseRevision=doc['queue']['revision'], bookIds=[])
    assert post(bookcase, **body).status_code == 200
    assert get(bookcase)['queue']['bookIds'] == [], 'A user-removed queue item must stay removed'


def test_migrate_existing_app_state_preserves_listening_date(bookcase):
    record = {'revision': 7, 'mutationId': str(uuid.uuid4()), 'updatedAt': 1704067200000,
              'progress': mutation()['progress']}
    bookcase.sql('general', 'INSERT INTO user_settings(user_id,key,value) VALUES(1,?,?)',
                 ('AUDIOBOOK_OPDS_SYNC_V1_U1_B1', json.dumps(record)))
    doc = get(bookcase)
    assert native(bookcase)['last_listened_at'].startswith('2024-01-01')
    assert doc['progress']['1']['revision'] == 7
    assert doc['progress']['1']['updatedAt'] == 1704067200000


def test_newer_existing_web_record_wins_initial_migration(bookcase):
    record = {'revision': 7, 'updatedAt': 1, 'progress': mutation()['progress']}
    bookcase.sql('general', 'INSERT INTO user_settings(user_id,key,value) VALUES(1,?,?)',
                 ('AUDIOBOOK_OPDS_SYNC_V1_U1_B1', json.dumps(record)))
    web(bookcase, position=.3)
    assert get(bookcase)['progress']['1']['progress']['position'] == .3
    assert native(bookcase)['current_time'] == .3


def test_native_records_are_filtered_by_permission_and_ownership(bookcase):
    for bid, tid, uid in [(3,3,1), (4,4,1), (6,7,1), (1,1,5)]:
        web(bookcase, bid=bid, tid=tid, uid=uid)
    doc = get(bookcase)
    assert doc['progress'] == {} and doc['queue']['bookIds'] == []
    assert post(bookcase, **mutation(bookId=3)).status_code == 404


def test_retry_does_not_rewrite_recent_time_or_increase_revision(bookcase):
    body = mutation()
    first = post(bookcase, **body)
    row = native(bookcase)
    assert row
    assert post(bookcase, **body).json == first.json
    assert native(bookcase) == row


def test_completed_native_book_clamps_legacy_whole_book_seconds(bookcase):
    web(bookcase, bid=5, tid=6, position=4, completed=1)
    state = get(bookcase)['progress']['5']['progress']
    assert state['position'] == state['duration'] == 2
    assert state['completed'] is True


def test_unknown_web_duration_does_not_invent_total_or_overwrite_web(bookcase):
    bookcase.sql('audiobook', 'UPDATE audiobook_tracks SET duration=0 WHERE id=1')
    web(bookcase, position=200)
    doc = get(bookcase)
    assert 'progress' not in doc['progress']['1'], 'Never invent a duration for older app clients'
    assert post(bookcase, **mutation()).status_code == 409
    assert native(bookcase)['current_time'] == 200


def test_web_can_resume_track_with_app_cached_duration(bookcase):
    bookcase.sql('audiobook', 'UPDATE audiobook_tracks SET duration=0 WHERE id=1')
    saved = post(bookcase, **mutation()).json['record']
    assert native(bookcase)
    web(bookcase, position=.6)
    doc = get(bookcase)
    assert doc['progress']['1']['progress']['duration'] == 2
    assert doc['progress']['1']['progress']['position'] == .6
    assert doc['progress']['1']['revision'] == saved['revision'] + 1


def test_late_server_duration_allows_deferred_web_resume(bookcase):
    bookcase.sql('audiobook', 'UPDATE audiobook_tracks SET duration=0 WHERE id=1')
    web(bookcase, position=200)
    first = get(bookcase)['progress']['1']
    assert 'progress' not in first
    bookcase.sql('audiobook', 'UPDATE audiobook_tracks SET duration=600 WHERE id=1')
    second = get(bookcase)['progress']['1']
    assert second['progress']['position'] == 200
    assert second['progress']['duration'] == 600
    assert second['revision'] == first['revision'] + 1


def test_web_write_between_reconcile_and_mirror_is_not_lost(bookcase, monkeypatch):
    from services.plugin_db_gateway import PluginDatabaseGateway
    original = PluginDatabaseGateway.execute
    fired = []
    def race(self, query, params=()):
        if self.db_type == 'audiobook' and 'INSERT INTO audiobook_progress' in query and not fired:
            fired.append(True)
            web(bookcase, position=.2)
        return original(self, query, params)
    monkeypatch.setattr(PluginDatabaseGateway, 'execute', race)
    r = post(bookcase, **mutation())
    assert fired and r.status_code == 409
    assert r.json['record']['progress']['position'] == .2
    assert native(bookcase)['current_time'] == .2


def test_pending_mirror_recovers_after_database_failure(bookcase, monkeypatch):
    from services.plugin_db_gateway import PluginDatabaseGateway
    original = PluginDatabaseGateway.execute
    fired = []
    def failure(self, query, params=()):
        if self.db_type == 'audiobook' and 'INSERT INTO audiobook_progress' in query and not fired:
            fired.append(True)
            raise sqlite3.OperationalError('test transient database failure')
        return original(self, query, params)
    monkeypatch.setattr(PluginDatabaseGateway, 'execute', failure)
    body = mutation()
    assert post(bookcase, **body).status_code == 503
    retry = post(bookcase, **body)
    assert retry.status_code == 200 and retry.json['record']['revision'] == 1
    assert native(bookcase)['current_time'] == 1.25


def test_pending_mirror_recovers_after_native_commit(bookcase, monkeypatch):
    from services.plugin_db_gateway import PluginDatabaseGateway
    original = PluginDatabaseGateway.execute
    fired = []
    def failure(self, query, params=()):
        if self.db_type == 'audiobook' and 'INSERT INTO audiobook_track_progress' in query and not fired:
            fired.append(True)
            raise sqlite3.OperationalError('test failure after main native commit')
        return original(self, query, params)
    monkeypatch.setattr(PluginDatabaseGateway, 'execute', failure)
    body = mutation()
    assert post(bookcase, **body).status_code == 503
    before = native(bookcase)
    assert before['current_time'] == 1.25
    assert post(bookcase, **body).status_code == 200
    assert native(bookcase) == before
    with sqlite3.connect(bookcase.paths['audiobook']) as c:
        assert c.execute('SELECT COUNT(*) FROM audiobook_track_progress').fetchone()[0] == 1


def test_cache_invalidated_on_save_but_not_poll(bookcase, plugin, monkeypatch):
    calls = []
    monkeypatch.setattr(plugin, '_invalidate_native_history', calls.append)
    assert post(bookcase, **mutation()).status_code == 200
    assert calls == [1]
    get(bookcase)
    get(bookcase)
    assert calls == [1]


def test_web_change_after_native_commit_survives_retry(bookcase, monkeypatch):
    from services.plugin_db_gateway import PluginDatabaseGateway
    original = PluginDatabaseGateway.execute
    fired = []
    def race(self, query, params=()):
        if self.db_type == 'audiobook' and 'INSERT INTO audiobook_track_progress' in query and not fired:
            fired.append(True)
            web(bookcase, position=.4)
        return original(self, query, params)
    monkeypatch.setattr(PluginDatabaseGateway, 'execute', race)
    r = post(bookcase, **mutation())
    assert r.status_code == 409
    assert native(bookcase)['current_time'] == .4
    assert r.json['record']['progress']['position'] == .4


def test_unrelated_book_metadata_is_untouched(bookcase):
    with sqlite3.connect(bookcase.paths['audiobook']) as c:
        before = c.execute('SELECT * FROM audiobooks').fetchall()
        tracks = c.execute('SELECT * FROM audiobook_tracks').fetchall()
        schema = c.execute('SELECT sql FROM sqlite_master ORDER BY name').fetchall()
    assert post(bookcase, **mutation()).status_code == 200
    with sqlite3.connect(bookcase.paths['audiobook']) as c:
        assert c.execute('SELECT * FROM audiobooks').fetchall() == before
        assert c.execute('SELECT * FROM audiobook_tracks').fetchall() == tracks
        assert c.execute('SELECT sql FROM sqlite_master ORDER BY name').fetchall() == schema
