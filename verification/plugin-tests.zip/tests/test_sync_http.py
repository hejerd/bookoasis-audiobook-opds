"""Two independent real client engines over HTTP, with a short fixture audiobook."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import threading
import pytest
from werkzeug.serving import make_server


def test_two_devices_over_http(bookcase):
    configured = os.environ.get("BOOKOASIS_SYNC_ENGINE")
    if not configured:
        pytest.skip("Set BOOKOASIS_SYNC_ENGINE to the esbuild-bundled syncEngine.ts for this optional cross-language test")
    engine = Path(configured).resolve()
    assert engine.is_file()
    node = shutil.which("node")
    assert node, "Node is required for the real TypeScript client engine"
    server = make_server("127.0.0.1", 0, bookcase.app, threaded=True)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    program = r'''
const assert = require('node:assert/strict');
const {BookOasisSyncEngine} = require(process.argv[1]);
const endpoint = process.argv[2];
const auth = 'Basic ' + Buffer.from('reader:test-reader-password').toString('base64');
const make = () => {
 let saved = '';
 return new BookOasisSyncEngine({load:()=>saved,save:(text)=>{saved=text;},
  get:async()=>{const r=await fetch(endpoint,{headers:{Authorization:auth}});assert.equal(r.status,200);return r.json();},
  post:async(body)=>{const r=await fetch(endpoint,{method:'POST',headers:{Authorization:auth,'Content-Type':'application/json'},body:JSON.stringify(body)});
   assert.ok([200,409].includes(r.status));const value=await r.json();return {conflict:r.status===409,record:value.record};}});
};
(async()=>{
 const a=make(),b=make();
 await a.sync(); await b.sync();
 a.setQueue([5,1]);
 a.setProgress(5,{trackId:6,position:1.2,duration:2,speed:1.5,completed:false});
 await a.sync(); await b.sync();
 assert.deepEqual(b.queue,[5,1]); assert.equal(b.document.books[0].tracks.length,2);
 assert.equal(b.document.progress['5'].progress.position,1.2);
 assert.equal(b.document.progress['5'].progress.trackId,6);
 a.setProgress(5,{trackId:6,position:1.3,duration:2,speed:1.5,completed:false});
 b.setProgress(5,{trackId:6,position:1.6,duration:2,speed:1.75,completed:false});
 await b.sync(); await a.sync();
 assert.deepEqual(a.conflicts,['B5']); assert.equal(a.document.progress['5'].progress.position,1.6);
 a.resolve('B5','server'); await a.sync();
 assert.equal(a.pendingCount,0);
 a.setQueue([1,5]); await a.sync(); await b.sync();
 assert.deepEqual(b.queue,[1,5]);
 console.log(JSON.stringify({two_devices:true,track_resume:true,speed:true,playlist_order:true,stale_offline_blocked:true,explicit_resolution:true}));
})().catch((e)=>{console.error(e);process.exitCode=1;});
'''
    try:
        result = subprocess.run([node, "-e", program, str(engine), f"http://127.0.0.1:{server.server_port}/opds/sync/v1"],
                                capture_output=True, text=True, timeout=60)
        assert result.returncode == 0, result.stdout + result.stderr
        assert json.loads(result.stdout)["stale_offline_blocked"] is True
    finally:
        server.shutdown()
        thread.join(timeout=5)
