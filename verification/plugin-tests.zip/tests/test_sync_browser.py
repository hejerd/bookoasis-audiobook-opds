"""Optional browser-driven, real HTTP verification in a temporary fixture DB."""
import json
import os
from pathlib import Path
import threading
import time
import pytest
from werkzeug.serving import make_server


def test_browser_sync_session(bookcase):
    configured = os.environ.get("BOOKOASIS_BROWSER_RESULT")
    if not configured:
        pytest.skip("Set BOOKOASIS_BROWSER_RESULT and open the printed local verification page")
    output = Path(configured).resolve()
    bundle = Path(os.environ["BOOKOASIS_BROWSER_BUNDLE"]).resolve().read_bytes()
    result = []
    event = threading.Event()
    html = '''<!doctype html><html lang="ko"><meta charset="utf-8"><title>BookOasis 로컬 동기화 검증</title>
<meta name="viewport" content="width=device-width,initial-scale=1"><style>body{font:17px system-ui;max-width:700px;margin:40px auto;padding:20px;background:#f6f7f8;color:#15232c}button{padding:12px 20px;font:inherit}pre{white-space:pre-wrap;background:white;padding:20px;border:1px solid #abc}</style>
<h1>BookOasis 동기화 로컬 통합 테스트</h1><p>임시 DB와 짧은 샘플 오디오북을 사용합니다. Android 실기 검증은 별도입니다.</p>
<button id="run">동기화 테스트 실행</button><pre id="output">대기 중</pre><script src="/verification/engine.js"></script><script>
const log=document.querySelector('#output');
const check=(condition,message)=>{if(!condition)throw Error(message);log.textContent+='\\n✓ '+message;};
document.querySelector('#run').onclick=async()=>{
 document.querySelector('#run').disabled=true; log.textContent='검증 중';
 const endpoint=location.origin+'/opds/sync/v1';
 const auth='Basic '+btoa('reader:test-reader-password');
 const make=()=>{let saved='';return new BookOasisEngine.BookOasisSyncEngine({load:()=>saved,save:(text)=>saved=text,
 get:async()=>{const r=await fetch(endpoint,{headers:{Authorization:auth}});if(!r.ok)throw Error('GET '+r.status);return r.json();},
 post:async(body)=>{const r=await fetch(endpoint,{method:'POST',headers:{Authorization:auth,'Content-Type':'application/json'},body:JSON.stringify(body)});
 if(![200,409].includes(r.status))throw Error('POST '+r.status);const value=await r.json();return{conflict:r.status===409,record:value.record};}});};
 try{
  const a=make(),b=make();await a.sync();await b.sync();
  a.setQueue([5,1]);a.setProgress(5,{trackId:6,position:1.2,duration:2,speed:1.5,completed:false});
  await a.sync();await b.sync();
  check(JSON.stringify(b.queue)==='[5,1]','서버 재생목록을 두 번째 클라이언트에 복원');
  check(b.document.books[0].tracks.length===2,'원래 회차 목록 유지');
  check(b.document.progress['5'].progress.position===1.2&&b.document.progress['5'].progress.trackId===6,'현재 회차와 초 단위 위치 복원');
  check(b.document.progress['5'].progress.speed===1.5,'재생 배속 복원');
  a.setProgress(5,{trackId:6,position:1.3,duration:2,speed:1.5,completed:false});
  b.setProgress(5,{trackId:6,position:1.6,duration:2,speed:1.75,completed:false});
  await b.sync();await a.sync();
  check(JSON.stringify(a.conflicts)==='["B5"]'&&a.document.progress['5'].progress.position===1.6,'오래된 오프라인 기록의 덮어쓰기 차단');
  a.resolve('B5','server');await a.sync();check(a.pendingCount===0,'서버 기록을 선택해 충돌 해결');
  a.setQueue([1,5]);await a.sync();await b.sync();check(JSON.stringify(b.queue)==='[1,5]','재생목록 순서 변경을 다른 클라이언트에 반영');
  log.textContent+='\\n\\n모든 로컬 HTTP 검증 통과';
  await fetch('/verification/result',{method:'POST',body:JSON.stringify({passed:true,checks:7,android_device_tested:false,transport:'real HTTP',clients:'two independent TypeScript engines'})});
 }catch(error){log.textContent+='\\n실패: '+error.message;await fetch('/verification/result',{method:'POST',body:JSON.stringify({passed:false,error:error.message})});}
};</script></html>'''.encode()
    def harness(environ, start_response):
        path = environ.get("PATH_INFO", "")
        if path == "/verification":
            start_response("200 OK", [("Content-Type", "text/html;charset=utf-8")]); return [html]
        if path == "/verification/engine.js":
            start_response("200 OK", [("Content-Type", "text/javascript")]); return [bundle]
        if path == "/verification/result" and environ["REQUEST_METHOD"] == "POST":
            data = environ["wsgi.input"].read(min(8192, int(environ.get("CONTENT_LENGTH") or 0)))
            result.append(json.loads(data)); output.write_text(json.dumps(result[-1], indent=2), encoding="utf-8")
            event.set(); start_response("200 OK", [("Content-Type", "text/plain")]); return [b"ok"]
        return bookcase.app(environ, start_response)
    server = make_server("127.0.0.1", 15941, harness, threaded=True)
    thread = threading.Thread(target=server.serve_forever, daemon=True); thread.start()
    output.with_suffix(".ready.json").write_text(json.dumps({"url":"http://127.0.0.1:15941/verification"}), encoding="utf-8")
    try:
        deadline = time.monotonic() + 600
        while not event.wait(1) and time.monotonic() < deadline:
            pass
        assert result and result[-1]["passed"], result
    finally:
        server.shutdown(); thread.join(timeout=5)
